//
//  CollectionViewCell.swift
//  Hungry
//
//  Created by Melody park on 10/29/17.
//  Copyright © 2017 Melody park. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var image: UIImageView!
}
