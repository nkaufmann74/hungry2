# Hungry
Ios Food App: Hungry? 


Implementation Contributions:
Nikki Kaufmann 33%
Login Screen
Register Screen

Melody Park 33%
Learned the API
Filter Screen
Home Screen

Rebekkah Koo 33%
Shopping List
Recipe Box

Grading Level: Same grade for all members.

Differences: None

Special Instructions:
None
